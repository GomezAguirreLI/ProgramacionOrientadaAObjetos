from tkinter import messagebox
from model import operaciones
class Funciones:
    @staticmethod
    def operaciones(n1,n2,signo):
        if signo=="+":
            ope=n1+n2
            tipo_ope="Suma"
        elif signo=="-":
            ope=n1-n2
            tipo_ope="Resta"
        elif signo=="x":
            ope=n1*n2
            tipo_ope="Multiplicacion"  
        elif signo=="/":
            ope=n1/n2
            tipo_ope="Divsion"

        resultado=messagebox.askquestion(message=f"{n1}{signo}{n2}={ope} ¿Deseas guardar en la base de datos",icon="question")
        if resultado=="yes":
            operaciones.Operaciones.insertar(n1,n2,signo,ope)