from tkinter import messagebox
from tkinter import *
from controller import funciones
#Interfaz o view

class Vista:
    def __init__(self,ventana):
        ventana=Tk()
        ventana.title("Calculadora")
        ventana.geometry("600x400")
        ventana.resizable(False,False)
        self.interfaz_principal(ventana)

    def interfaz_principal(self,ventana):
        Vista.menuPrincipal(ventana)    
        
        ventana.title("Calculadora")
        ventana.geometry("600x400")
        ventana.resizable(False,False)

        #Variables para los entry
        n1=IntVar()
        n2=IntVar()

        txt_numero1=Entry(ventana,textvariable=n1,width=5,justify="right")
        txt_numero1.pack(side="top",anchor="center")

        txt_numero2=Entry(ventana,textvariable=n2,width=5,justify="right")
        txt_numero2.pack(side="top",anchor="center")

        btn_suma=Button(ventana,text="+",command=lambda: funciones.Funciones.operaciones(n1.get(),n2.get(),"+"))
        btn_suma.pack()

        btn_resta=Button(ventana,text="-",command=lambda:funciones.Funciones.operaciones(n1.get(),n2.get(),"-"))
        btn_resta.pack()

        btn_multiplicacion=Button(ventana,text="X",command=lambda:funciones.Funciones.operaciones(n1.get(),n2.get(),"x"))
        btn_multiplicacion.pack()

        btn_division=Button(ventana,text="/",command=lambda:funciones.Funciones.operaciones(n1.get(),n2.get(),"/"))
        btn_division.pack()


        btn_salir=Button(ventana,text="Salir",command=ventana.quit)
        btn_salir.pack()
        ventana.mainloop()
 
   


    @staticmethod
    def menuPrincipal(ventana):
        menuBar=Menu(ventana)
        ventana.config(menu=menuBar)

        operacionesMenu=Menu(menuBar,tearoff=False)
        menuBar.add_cascade(label='Operaciones',menu=operacionesMenu)
        operacionesMenu.add_command(label='Agregar',command=lambda:"")
        operacionesMenu.add_command(label='Consultar',command=lambda:"")
        operacionesMenu.add_command(label='Cambiar',command=lambda:"")
        operacionesMenu.add_command(label='Borrar',command=lambda:Vista.eliminar_screen(ventana))
        operacionesMenu.add_separator()
        operacionesMenu.add_command(label="Salir",command=ventana.quit)

    @staticmethod
    def eliminar_screen(ventana):
        Vista.borrarPantalla(ventana)
        lbl_titulo=Label(ventana,text=f".:: Borrar una operacion ::.")
        lbl_titulo.pack(pady=10)
        lbl_id=Label(ventana,text="ID de la Operacion: ")
        lbl_id.pack(pady=5)
        id=IntVar()
        txt_id=Entry(ventana,textvariable=id,justify="right",width=5)
        txt_id.focus()
        txt_id.pack(pady=5)


        btn_eliminar=Button(ventana,text="Eliminar",command=lambda:"")
        btn_eliminar.pack(pady=5)
        btn_volver=Button(ventana,text="Volver",command="")
        btn_volver.pack(pady=5)


    #Borrar pantalla
    def borrarPantalla(ventana):
        for widget in ventana.winfo_children():
            widget.destroy()
    